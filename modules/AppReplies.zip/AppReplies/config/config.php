<?php

return [
    'name' => 'AppReplies',
];
