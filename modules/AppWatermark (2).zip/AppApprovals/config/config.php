<?php

return [
    'name' => 'AppApprovals',
];
