<?php

return [
    'name' => 'AppAffiliate',
];
