<?php

return [
    'name' => 'AppChannelLinkedinPages',
];
