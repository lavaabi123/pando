<?php

return [
    'name' => 'AppBulkPost',
];
