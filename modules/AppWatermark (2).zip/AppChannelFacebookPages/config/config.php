<?php

return [
    'name' => 'AppChannelFacebookPages',
];
