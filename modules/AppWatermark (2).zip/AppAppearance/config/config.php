<?php

return [
    'name' => 'AppAppearance',
];
