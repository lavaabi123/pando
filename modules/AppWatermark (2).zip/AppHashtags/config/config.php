<?php

return [
    'name' => 'AppHashtags',
];
