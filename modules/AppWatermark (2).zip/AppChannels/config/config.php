<?php

return [
    'name' => 'AppChannels',
];
