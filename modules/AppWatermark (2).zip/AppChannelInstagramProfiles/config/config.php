<?php

return [
    'name' => 'AppChannelInstagramProfiles',
];
