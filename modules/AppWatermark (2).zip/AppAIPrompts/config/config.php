<?php

return [
    'name' => 'AppAIPrompts',
];
