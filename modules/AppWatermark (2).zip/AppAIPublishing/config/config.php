<?php

return [
    'name' => 'AppAIPublishing',
];
