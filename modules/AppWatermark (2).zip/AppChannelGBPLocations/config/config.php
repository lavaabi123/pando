<?php

return [
    'name' => 'AppChannelGBPLocations',
];
