<?php

return [
    'name' => 'AppDashboard',
];
