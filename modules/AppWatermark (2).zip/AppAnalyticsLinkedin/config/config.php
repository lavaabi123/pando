<?php

return [
    'name' => 'AppAnalyticsLinkedin',
];
