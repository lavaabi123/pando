<?php

return [
    'name' => 'AppChannelXUnofficial',
];
