<?php

return [
    'name' => 'AppChannelFacebookProfiles',
];
