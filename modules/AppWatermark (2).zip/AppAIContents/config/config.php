<?php

return [
    'name' => 'AppAIContents',
];
