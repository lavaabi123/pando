<?php

return [
    'name' => 'AppWatermark',
];
