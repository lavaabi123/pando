<?php

return [
    'name' => 'AppChannelPinterestBoards',
];
