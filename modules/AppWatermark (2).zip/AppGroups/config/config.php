<?php

return [
    'name' => 'AppGroups',
];
