<?php

return [
    'name' => 'AppChannelTiktokProfiles',
];
