<?php

return [
    'name' => 'AppAnalytics',
];
