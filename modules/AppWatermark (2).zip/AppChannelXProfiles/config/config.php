<?php

return [
    'name' => 'AppChannelXProfiles',
];
