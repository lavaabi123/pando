<?php

return [
    'name' => 'AppAnalyticsFacebook',
];
