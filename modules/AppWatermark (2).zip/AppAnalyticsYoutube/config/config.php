<?php

return [
    'name' => 'AppAnalyticsYoutube',
];
