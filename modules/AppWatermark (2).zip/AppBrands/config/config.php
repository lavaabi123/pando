<?php

return [
    'name' => 'AppBrands',
];
