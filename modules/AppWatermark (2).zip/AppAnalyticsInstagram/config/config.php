<?php

return [
    'name' => 'AppAnalyticsInstagram',
];
