<?php

return [
    'name' => 'AppCaptions',
];
