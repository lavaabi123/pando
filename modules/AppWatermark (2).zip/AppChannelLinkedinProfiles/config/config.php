<?php

return [
    'name' => 'AppChannelLinkedinProfiles',
];
