<?php

return [
    'name' => 'AppAnalyticsTiktok',
];
