<?php

return [
    'name' => 'AppChannelInstagramUnofficial',
];
