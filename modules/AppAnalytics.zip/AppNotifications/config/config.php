<?php

return [
    'name' => 'AppNotifications',
];
