<?php

return [
    'name' => 'AppProxies',
];
