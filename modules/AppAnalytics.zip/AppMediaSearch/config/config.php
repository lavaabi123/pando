<?php

return [
    'name' => 'AppMediaSearch',
];
