<?php

return [
    'name' => 'AppProfile',
];
