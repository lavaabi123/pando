<?php

return [
    'name' => 'AppPublishing',
];
